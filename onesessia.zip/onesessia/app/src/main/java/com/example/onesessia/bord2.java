//Сделала Швецова Мария Сергеенва 3ИСиП-21-3к
//01.04.2023

package com.example.onesessia;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class bord2 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.bord2);
    }
    public void Next4(View v) {
        Intent intent = new Intent(this, vord3.class);
        startActivity(intent);
    }
}
//По нажатию кнопки Next1 поисходит переход на другой экран vord3
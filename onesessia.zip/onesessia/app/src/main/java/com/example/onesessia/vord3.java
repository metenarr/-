//Сделала Швецова Мария Сергеенва 3ИСиП-21-3к
//01.04.2023

package com.example.onesessia;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class vord3 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_vord3);
    }
    public void SignUp(View v) {
        Intent intent = new Intent(this, signup.class);
        startActivity(intent);
    }
    public void SignIn1(View v) {
        Intent intent = new Intent(this, loginin.class);
        startActivity(intent);
    }
}
